python train.py --lr 0.001 --batch_size 250 --dropout_prob 0.4 --decode_method GREEDY --attention --epochs 20 --save_dir saveDir
