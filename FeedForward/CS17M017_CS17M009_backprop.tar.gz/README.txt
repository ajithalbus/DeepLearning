TEAM NAME: LiveWire
Members: Jeshuren Chelladurai(CS17M017) and Ajith Kumar M(CS17M009)

Instructions:
To train the model from scratch: Run "run.sh" file

To get preictions from the trained model: Run "getPresdictions.sh" file.